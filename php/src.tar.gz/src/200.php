<?php
$a = 10;
$b = 5;

define('AMPLADA',2);

$resultado = $a + $b + AMPLADA;

echo $resultado;
