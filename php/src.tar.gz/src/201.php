<?php
$altura = 5;
$amplada = 10;

define('FACTOR', 2);

$area = $altura * $amplada * FACTOR;

echo "àrea del rectangle és: $area";
?>
