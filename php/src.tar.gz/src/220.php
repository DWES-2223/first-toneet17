<!DOCTYPE html>
<html>
<head>
    <title>220.php</title>
</head>
<body>
<ul>
    <?php
    for ($i = 2; $i <= 50; $i += 2) {
        echo "<li>$i</li>";
    }
    ?>
</ul>
</body>
</html>
