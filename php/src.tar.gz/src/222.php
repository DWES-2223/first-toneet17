<!DOCTYPE html>
<html>
<head>
    <title>Calculadora de Potencia</title>
</head>
<body>
<?php
// Comprobar si se han proporcionado la base y el exponente a través del QueryString
if (isset($_GET['base']) && isset($_GET['exponent'])) {
    $base = $_GET['base'];
    $exponent = $_GET['exponent'];

    // Inicializar el resultado
    $resultado = 1;

    // Calcular la potencia utilizando un bucle for
    for ($i = 1; $i <= $exponent; $i++) {
        $resultado *= $base;
    }

    // Mostrar el resultado
    echo "<p>$base^$exponent = $resultado</p>";
} else {
    echo "<p>Posa la base i l'exponent a les variables base i exponent pel QueryString</p>";
}
?>
</body>
</html>
