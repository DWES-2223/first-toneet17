<!DOCTYPE html>
<html>
<head>
    <title>Tabla de Multiplicar</title>
</head>
<body>
<?php
// Comprobar si se ha proporcionado el número a través del QueryString
if (isset($_GET['nombre'])) {
    $numero = $_GET['nombre'];
    echo "<table>";
    echo "<thead>";
    echo "<tr><th>a</th><th>*</th><th>b</th><th>=</th><th>a*b</th></tr>";
    echo "</thead>";
    echo "<tbody>";

    for ($i = 1; $i <= 10; $i++) {
        $resultado = $numero * $i;
        echo "<tr> <td>$numero</td> <td>*</td> <td>$i</td> <td>=</td> <td>$resultado</td> </tr>";
    }
    echo "</tbody>";
    echo "</table>";
} else {
    echo "<p>Posa el nombre pel QueryString</p>";
}
?>
</body>
</html>
