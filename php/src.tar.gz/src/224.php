<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resultat</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $quantitat = $_POST["quantitat"];
    $total = 0;

    if (is_numeric($quantitat)) {
        $total = 0;
        for ($i = 0; $i < $quantitat; $i++) {
            $input_name = "quantitat" . $i;
            if (isset($_POST[$input_name]) && is_numeric($_POST[$input_name])) {
                $total += $_POST[$input_name];
            }
        }
    }
}
?>

<div class="container mt-4">
    <h2>Total:</h2>
    <p><?php echo $total; ?></p>
</div>
</body>
</html>
